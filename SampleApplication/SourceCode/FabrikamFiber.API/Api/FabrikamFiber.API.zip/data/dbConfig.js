﻿var dbConfig = { config : { "user": "demouser", "password": "rQ53uUn3rm", "server": "localhost", "database": "FabrikamFiber" } };
module.exports = dbConfig;