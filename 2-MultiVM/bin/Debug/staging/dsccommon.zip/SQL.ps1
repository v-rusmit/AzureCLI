Configuration DemoSQL
{
	param
	(
        [string[]]     $AppName,
		[PSCredential] $UserAccount
    )
	
	Import-DscResource -Module xPSDesiredStateConfiguration
	
	$bacpac = "FabrikamFiber.bacpac"
	$storacct = "https://clijson.blob.core.windows.net/common-stageartifacts/"

    LocalConfigurationManager
    {
        RebootNodeIfNeeded = $true
    }

	xRemoteFile GetBacpac
	{  
		URI             = $storacct + $bacpac
		DestinationPath = "C:\Packages\$bacpac"
	}    

} 