Configuration DemoIIS
{
	param
	(
        [string[]]     $AppName,
		[PSCredential] $UserAccount
    )
	
	Import-DscResource -Module xWebAdministration
	Import-DscResource -Module xPSDesiredStateConfiguration

	$webzip = "FabrikamFiber.Web.zip"
	$folder = "C:\inetpub\wwwroot"
	$storacct = "https://clijson.blob.core.windows.net/common-stageartifacts/"

    LocalConfigurationManager
    {
        RebootNodeIfNeeded = $true
    }

    WindowsFeature IIS
    {
        Name   = "Web-Server"
        Ensure = "Present"
    }

	WindowsFeature IISCommon
	{  
		Name                 = "Web-Common-Http"
		Ensure               = "Present"
		IncludeAllSubFeature = $true
 		DependsOn            = "[WindowsFeature]IIS"
	}  

	WindowsFeature URLAuth
	{  
		Name      = "Web-Url-Auth"
		Ensure    = "Present"
		DependsOn = "[WindowsFeature]IIS"
	}  

	WindowsFeature WindowsAuth
	{  
		Name      = "Web-Windows-Auth"
		Ensure    = "Present"
		DependsOn = "[WindowsFeature]IIS"
	}  

	WindowsFeature AspNet35
	{  
		Name      = "Web-Asp-Net"
		Ensure    = "Present"
		DependsOn = "[WindowsFeature]IIS"
	}  

	WindowsFeature AspNet45
	{  
		Name      = "Web-Asp-Net45"
		Ensure    = "Present"
		DependsOn = "[WindowsFeature]IIS"
	}  

	WindowsFeature Core
	{  
		Name      = "Web-WHC"
		Ensure    = "Present"
		DependsOn = "[WindowsFeature]IIS"
	}  

	WindowsFeature IISMgmtTools
	{  
		Name                 = "Web-Mgmt-Tools"
		Ensure               = "Present"
		IncludeAllSubFeature = $true
		DependsOn            = "[WindowsFeature]IIS"
	}  




	xWebsite DefaultSite
	{  
		Ensure          = "Present"
		Name            = "Default Web Site"
		State           = "Stopped"
		PhysicalPath    = "C:\Inetpub\wwwroot"
		DependsOn       = "[WindowsFeature]IIS"
	}  





	Archive WebContent
	{  
		Ensure      = "Present"
		Path        = "C:\Packages\$webzip"
		Destination = "$folder"
		DependsOn   = "[xRemoteFile]WebContent"
	}         

	xRemoteFile WebContent
	{  
		URI             = $storacct + $webzip
		DestinationPath = "C:\Packages\$webzip"
	}         





	xWebsite Fabrikam
	{  
		Ensure          = "Present"
		Name            = "Sample Application" 
		State           = "Started"
		PhysicalPath    = "$folder"
		DependsOn       = "[Archive]WebContent1","[Archive]WebContent2"
	}  
} 