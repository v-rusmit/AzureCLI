configuration DemoAD1
{
	param
	(
        [string[]]     $AppName,
		[Parameter(Mandatory=$true)] [ValidateNotNullorEmpty()] [PSCredential] $UserAccount
    )

	$domain = "Fabrikam.com"
	
	$secpasswd = ConvertTo-SecureString "Sw!mmingP00l"  -AsPlainText -Force
	$newpasswd = ConvertTo-SecureString "Sw!mmingP00ls" -AsPlainText -Force
	
	[PSCredential]$domainCred =                New-Object System.Management.Automation.PSCredential ("Fabrikam\AzureAdmin", $secpasswd)
	[PSCredential]$safemodeAdministratorCred = New-Object System.Management.Automation.PSCredential ("Fabrikam\AzureAdmin", $secpasswd)
	[PSCredential]$localcred =                 New-Object System.Management.Automation.PSCredential (         "AzureAdmin", $secpasswd)
	[PSCredential]$userCred =                  New-Object System.Management.Automation.PSCredential ("Fabrikam\AzureUser",  $newpasswd)

    Import-DscResource -ModuleName xActiveDirectory
	

	Node localhost
	{
		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true
			DebugMode = "ForceModuleImport"
		}

		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
		}

		xADDomain FirstDS
		{
			DomainName                    = $UserAccount                     #$domain
			DomainAdministratorCredential = $UserAccount                     #$domainCred
			SafemodeAdministratorPassword = $UserAccount                     #$safemodeAdministratorCred
    		DependsOn                     = "[WindowsFeature]ADDSInstall"
		}

		xWaitForADDomain DscForestWait
		{
		    DomainName           = $domain
		    DomainUserCredential = $UserAccount                              #$domaincred
		    RetryCount           = 20
		    RetryIntervalSec     = 30
		    DependsOn            = "[xADDomain]FirstDS"
		}

		xADUser FirstUser
		{
		    DomainName                    = $domain
		    DomainAdministratorCredential = $UserAccount                              #$domaincred
		    UserName                      = "AzureUser"
		    Password                      = $UserAccount                              #$userCred
		    Ensure                        = "Present"
		    DependsOn                     = "[xWaitForADDomain]DscForestWait"
		}
	}
}

#$ConfigData = @{
#    AllNodes = @(
#        @{
#            NodeName = 'localhost'
#            PSDscAllowPlainTextPassword=$true
#        }
#    )
#}
 
#sl 'C:\Packages\'
#DemoAD1 -ConfigurationData $ConfigData
#Start-DscConfiguration -ComputerName 'localhost' -wait -force -verbose -path C:\Packages\DemoAD1
 
