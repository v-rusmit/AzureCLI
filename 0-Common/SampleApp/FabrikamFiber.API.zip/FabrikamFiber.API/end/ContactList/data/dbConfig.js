﻿var dbConfig = { config : { "user": "tjensen", "password": "Password1!", "server": "localhost", "database": "FabrikamFiber" } };
module.exports = dbConfig;