﻿var dbConfig = { config : { "user": "MSFTAzureARM", "password": "rQ53uUn3rm", "server": "localhost", "database": "FabrikamFiber" } };
module.exports = dbConfig;