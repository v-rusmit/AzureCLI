﻿var dbConfig = { config : { "user": "MSFTAzureARM", "password": "rQ53uUn3rm", "server": "10.0.2.4", "database": "FabrikamFiber" } };
module.exports = dbConfig;